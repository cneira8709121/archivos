﻿using System;
using System.Linq;
using System.Windows.Data;
using Ruv.Infrastructure.Crosscutting.Common;

namespace Ruv.WPF.Captura.Converters
{
    /// <summary>
    /// Retorna los parámetros para un tipo de parámetro.
    /// </summary>
    public class ListaParametrosConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            try
            {


                if (RUV.I.Util.EnModoDeDiseño) return null;

                string NombreTipoParametro = System.Convert.ToString(parameter);
                if (string.IsNullOrWhiteSpace(NombreTipoParametro)) return null;

                string[] parametros;
                string parametro1 = string.Empty;
                //Parametro adicional para identificar control que llama al converter
                if (NombreTipoParametro.Contains("|"))
                {
                    parametros = NombreTipoParametro.Split(System.Convert.ToChar("|"));
                    NombreTipoParametro = parametros[0];
                    parametro1 = parametros[1];
                }

                eTipoParametros TipoParametro;
                if (!Enum.TryParse<eTipoParametros>(NombreTipoParametro, out TipoParametro))
                    return null;

                // El régimen especial tiene el nulo como "Ninguno", los demás como "Sin información".
                var ParNulo = RUV.I.InfoGeneral.ParametroNulo;

                // Diego Alvarez - 13/09/2013 - Se incluye ninguno en la base de datos
                //if (TipoParametro == eTipoParametros.RegimenEspecial)
                //{
                //  ParNulo.ElementAt(0).Nombre = "ninguno";
                //}

                if (TipoParametro == eTipoParametros.TipoSecuestro
                    || TipoParametro == eTipoParametros.AfiliaciónASalud
                    || TipoParametro == eTipoParametros.Relacion
                    || TipoParametro == eTipoParametros.EstadoCivil
                    || TipoParametro == eTipoParametros.RegimenEspecial
                    || TipoParametro == eTipoParametros.Genero
                    || TipoParametro == eTipoParametros.OrientacionSexual
                    || TipoParametro == eTipoParametros.DiscapacidadEnActividades
                    || TipoParametro == eTipoParametros.TipoDeAccidente
                    || TipoParametro == eTipoParametros.EstadoActualLote
                    || TipoParametro == eTipoParametros.TipoTomaDeclaracion)
                {
                    return ParNulo.Concat(RUV.I.InfoGeneral.ListaParametros
                    .Where(x => x.Tipo == TipoParametro)
                    .OrderBy(x => x.Numero));
                }
                else if (TipoParametro == eTipoParametros.TipoDeDocumentoDeIdentidad && parametro1 == "TipoDocTutor")
                {
                    return ParNulo.Concat(RUV.I.InfoGeneral.ListaParametros
                        .Where(x => x.Tipo == TipoParametro && (x.Id == (int)eTipoDocumento.CedulaCiudadania || x.Id == (int)eTipoDocumento.CedulaExtranjeria))
                        .OrderBy(x => x.Nombre));
                }
                else if (TipoParametro == eTipoParametros.Entidades)
                {
                    return ParNulo.Concat(RUV.I.InfoGeneral.ListaParametros
                        .Where(x => x.Tipo == TipoParametro)
                        .OrderBy(x => x.Nombre));
                }
                else
                {
                    return ParNulo.Concat(RUV.I.InfoGeneral.ListaParametros
                      .Where(x => x.Tipo == TipoParametro)
                      .OrderBy(x => x.Nombre));
                }
            }
            catch (Exception)
            {

                return RUV.I.InfoGeneral.ParametroNulo;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return null;
        }
    }
}
